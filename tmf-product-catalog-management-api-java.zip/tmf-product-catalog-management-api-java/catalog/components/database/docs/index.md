# DB for TMF Product Catalog Management API

A backend database that is used to persist the product catalog data.